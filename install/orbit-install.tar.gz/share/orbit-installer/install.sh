#!/bin/sh

set -eu
umask 077

PATH="/opt/bin:/opt/sbin:/usr/sbin:/usr/bin:/sbin:/bin"
BUNDLE_DIR=$(CDPATH= cd "$(dirname "$0")" && pwd)
POLICY_NAME="Orbit"
RESET_DATA=no
case "${1:-}" in
    "") ;;
    --reset-data) RESET_DATA=yes ;;
    *) echo "Использование: sh install.sh [--reset-data]" >&2; exit 2 ;;
esac
[ "$#" -le 1 ] || { echo "Использование: sh install.sh [--reset-data]" >&2; exit 2; }

[ "$(id -u)" = "0" ] || { echo "Установщик нужно запустить от root" >&2; exit 1; }
[ -d /opt ] || { echo "/opt не смонтирован. Сначала подключите Entware-накопитель" >&2; exit 1; }
command -v opkg >/dev/null 2>&1 || { echo "opkg не найден. Сначала установите Entware" >&2; exit 1; }

case "$(uname -m)" in
    mips|mipsel) ;;
    *) echo "Этот пакет предназначен для MIPS little-endian (Keenetic Viva KN/NC-1913)" >&2; exit 1 ;;
esac

command -v ndmc >/dev/null 2>&1 || {
    echo "ОШИБКА: не удалось определить модель роутера: команда ndmc недоступна" >&2
    exit 1
}
device_version="$(ndmc -c "show version" 2>/dev/null || true)"
case "$device_version" in
    *KN-1913*|*NC-1913*) ;;
    *)
        echo "ОШИБКА: эта версия Orbit поддерживает только Keenetic Viva KN/NC-1913." >&2
        echo "Определено: ${device_version:-модель не определена}" >&2
        exit 1
        ;;
esac

"$BUNDLE_DIR/payload/orbit-mipsel" --verify-full-package "$BUNDLE_DIR"
for target in /opt/orbit /opt/lib/orbit /opt/etc/orbit /opt/var/lib/orbit /opt/etc/xray; do
    [ ! -L "$target" ] || { echo "ОШИБКА: ссылка $target не поддерживается, данные не изменены" >&2; exit 1; }
done
echo "=== Orbit: полная чистая установка ==="
echo "Политика Keenetic: $POLICY_NAME"

echo "Проверка комплекта..."
(cd "$BUNDLE_DIR" && sha256sum -c SHA256SUMS)

find_kernel_module() {
    module_name="$1"
    find /lib/modules /opt/lib/modules /opt/lib/system-modules \
        -name "${module_name}.ko" -type f 2>/dev/null | sed -n '1p'
}

for module_name in xt_comment xt_TPROXY; do
    if [ -z "$(find_kernel_module "$module_name")" ]; then
        echo "ОШИБКА: модуль ${module_name}.ko не найден." >&2
        echo "В KeeneticOS откройте «Компоненты операционной системы» → «Пакеты OPKG»" >&2
        echo "и установите «Модули ядра подсистемы Netfilter», затем повторите установку." >&2
        exit 1
    fi
done

mkdir -p /opt/var/backups /opt/var/tmp
backup_dir=$(mktemp -d /opt/var/backups/orbit-before.XXXXXX)
work_dir=$(mktemp -d /opt/var/tmp/orbit-installer.XXXXXX)
install_state_changed=no
install_completed=no

# Имя прежней системы собирается только внутри одноразовой миграции. Оно не
# является зависимостью Orbit и не используется после переноса данных.
retired_product='x''keen'
retired_config_dir="/opt/etc/$retired_product"
retired_binary="/opt/sbin/$retired_product"
retired_panel="${retired_product}-panel"

backup_path() {
    source_path="$1"
    name="$2"
    [ -e "$source_path" ] || return 0
    cp -a "$source_path" "$backup_dir/$name"
}

restore_path() {
    backup_name="$1"
    destination="$2"
    if [ "$destination" = /opt/orbit ] && [ -f "$backup_dir/$backup_name/orbit" ]; then
        mkdir -p /opt/orbit
        cp -p "$backup_dir/$backup_name/orbit" /opt/orbit/orbit.rollback
        mv -f /opt/orbit/orbit.rollback /opt/orbit/orbit
        return
    fi
    rm -rf "$destination"
    [ -e "$backup_dir/$backup_name" ] || return 0
    cp -a "$backup_dir/$backup_name" "$destination"
}

rollback_install() {
    [ "$install_state_changed" = "yes" ] || return 0
    echo "ОШИБКА: установка не завершена, восстанавливаем прежнюю версию" >&2
    [ -x /opt/etc/init.d/S99orbit ] && /opt/etc/init.d/S99orbit stop 2>/dev/null || true
    [ -x /opt/etc/init.d/S25orbit-network ] && /opt/etc/init.d/S25orbit-network stop 2>/dev/null || true
    [ -x /opt/etc/init.d/S24xray ] && /opt/etc/init.d/S24xray stop 2>/dev/null || true
    restore_path orbit-runtime /opt/orbit
    restore_path orbit-lib /opt/lib/orbit
    restore_path orbit-config /opt/etc/orbit
    restore_path orbit-data /opt/var/lib/orbit
    restore_path xray-config /opt/etc/xray
    restore_path xray-binary /opt/sbin/xray
    restore_path orbit-init /opt/etc/init.d/S99orbit
    restore_path orbit-network-init /opt/etc/init.d/S25orbit-network
    restore_path xray-init /opt/etc/init.d/S24xray
    restore_path orbit-netfilter-hook /opt/etc/ndm/netfilter.d/orbit.sh
    [ -x /opt/etc/init.d/S24xray ] && /opt/etc/init.d/S24xray start 2>/dev/null || true
    [ -x /opt/etc/init.d/S99orbit ] && /opt/etc/init.d/S99orbit start 2>/dev/null || true
    [ -x /opt/etc/init.d/S25orbit-network ] && /opt/etc/init.d/S25orbit-network start 2>/dev/null || true
}

installer_exit() {
    exit_code="$1"
    if [ "$exit_code" -ne 0 ] && [ "$install_completed" != "yes" ]; then
        rollback_install
    fi
    case "$work_dir" in /opt/var/tmp/orbit-installer.*) rm -rf "$work_dir" ;; esac
}
trap 'installer_exit $?' EXIT
trap 'exit 130' INT TERM

echo "Резервная копия старой установки: $backup_dir"
backup_path /opt/etc/orbit orbit-config
backup_path /opt/var/lib/orbit orbit-data
backup_path /opt/etc/xray xray-config
backup_path /opt/orbit orbit-runtime
backup_path /opt/lib/orbit orbit-lib
backup_path /opt/sbin/xray xray-binary
backup_path /opt/etc/init.d/S99orbit orbit-init
backup_path /opt/etc/init.d/S25orbit-network orbit-network-init
backup_path /opt/etc/init.d/S24xray xray-init
backup_path /opt/etc/ndm/netfilter.d/orbit.sh orbit-netfilter-hook
backup_path "$retired_config_dir" legacy-proxy-config
for stale_init in /opt/etc/init.d/S24xray.*; do
    [ -e "$stale_init" ] || continue
    backup_path "$stale_init" "legacy-$(basename "$stale_init")"
done

# 04_outbounds.json создаётся и изменяется самим Orbit. Перед заменой
# управляемых фрагментов Xray сохраняем его на том же накопителе /opt.
if [ "$RESET_DATA" = "no" ] && [ -f /opt/etc/xray/configs/04_outbounds.json ]; then
    cp -p /opt/etc/xray/configs/04_outbounds.json "$work_dir/04_outbounds.json"
fi

# При прямом обновлении переносим пользовательские списки в хранилище Orbit
# до удаления каталогов прежней установки.
if [ "$RESET_DATA" = "no" ] && [ -d "$retired_config_dir" ]; then
    mkdir -p "$work_dir/routing"
    for list_name in domain_direct.lst ip_exclude.lst port_exclude.lst port_proxying.lst; do
        [ -f "$retired_config_dir/$list_name" ] || continue
        cp -p "$retired_config_dir/$list_name" "$work_dir/routing/$list_name"
    done
fi

[ -x "$BUNDLE_DIR/payload/orbit-mipsel" ] || {
    echo "ОШИБКА: в комплекте отсутствует Orbit" >&2
    exit 1
}
# Извлекаем и проверяем Xray до изменения установленной системы. Ядро уже
# входит в Orbit, поэтому установка остаётся автономной без второй копии файла.
"$BUNDLE_DIR/payload/orbit-mipsel" \
    --extract-embedded-xray "$work_dir/xray.verified"
verified_xray_version=$("$work_dir/xray.verified" version 2>/dev/null | sed -n '1p' || true)
[ -n "$verified_xray_version" ] || {
    echo "ОШИБКА: встроенный Xray не прошёл проверку версии" >&2
    exit 1
}

install_state_changed=yes
echo "Остановка старых служб..."
[ -x /opt/etc/init.d/S99orbit ] && /opt/etc/init.d/S99orbit stop 2>/dev/null || true
attempt=0
while pidof orbit >/dev/null 2>&1; do
    attempt=$((attempt + 1))
    [ "$attempt" -lt 90 ] || { echo "Orbit не завершён, установка остановлена" >&2; exit 1; }
    sleep 1
done
[ -x /opt/etc/init.d/S25orbit-network ] && /opt/etc/init.d/S25orbit-network stop 2>/dev/null || true
[ -x /opt/lib/orbit/orbit-network ] && /opt/lib/orbit/orbit-network stop 2>/dev/null || true
[ -x /opt/etc/init.d/S24xray ] && /opt/etc/init.d/S24xray stop 2>/dev/null || true
for stale_init in /opt/etc/init.d/S24xray.*; do
    [ -x "$stale_init" ] && "$stale_init" stop 2>/dev/null || true
done
[ -x "/opt/etc/init.d/S05$retired_product" ] && "/opt/etc/init.d/S05$retired_product" stop 2>/dev/null || true

# Старый сетевой hook удаляем только при однозначном служебном маркере.
if [ -f /opt/etc/ndm/netfilter.d/proxy.sh ] && \
   grep -qi "$retired_product" /opt/etc/ndm/netfilter.d/proxy.sh 2>/dev/null; then
    rm -f /opt/etc/ndm/netfilter.d/proxy.sh
fi

echo "Удаление старых Orbit и Xray..."
# Точка запуска восстановления должна переживать отключение питания.
# Старый S99 заменяется атомарно только после готовности нового бинарника.
rm -f /opt/etc/init.d/S25orbit-network
rm -f /opt/etc/init.d/S24xray
rm -f /opt/etc/init.d/S24xray.*
rm -f /opt/etc/ndm/netfilter.d/orbit.sh
# Бинарник заменяется rename ниже. Даже при отключении питания остаётся
# исполняемая точка входа для восстановления транзакции.
rm -rf /opt/lib/orbit
rm -rf /opt/etc/xray
if [ "$RESET_DATA" = "yes" ]; then
    echo "Запрошен полный сброс пользовательских данных Orbit"
    rm -rf /opt/etc/orbit
    rm -rf /opt/var/lib/orbit
    rm -rf /opt/var/log/orbit
    rm -rf /opt/var/log/xray
fi
rm -f "/opt/etc/init.d/S05$retired_product" "/opt/etc/init.d/S99$retired_product"
rm -f "$retired_binary" "$retired_binary.old"
rm -rf "/opt/sbin/.$retired_product" "$retired_config_dir"
rm -f "/opt/var/log/$retired_product-detached.log"
rm -rf "/opt/var/log/$retired_product"
rm -rf "/opt/$retired_panel" "/opt/etc/$retired_panel" "/opt/var/lib/$retired_panel"
rm -f "/opt/etc/init.d/S99$retired_panel"

echo "Установка локальных Entware-пакетов..."
opkg install "$BUNDLE_DIR"/payload/ipk/*.ipk

# Заменяем установленное ядро проверенной копией из Orbit. Переход с любой
# старой версии не зависит от промежуточных релизов или доступности сети.
cp "$work_dir/xray.verified" /opt/sbin/xray.orbit-new
chmod 755 /opt/sbin/xray.orbit-new
installed_xray_version=$(/opt/sbin/xray.orbit-new version 2>/dev/null | sed -n '1p' || true)
if [ "$installed_xray_version" != "$verified_xray_version" ]; then
    rm -f /opt/sbin/xray.orbit-new
    echo "ОШИБКА: скопированный Xray не прошёл проверку версии" >&2
    exit 1
fi
mv -f /opt/sbin/xray.orbit-new /opt/sbin/xray

for command_name in iptables jq insmod; do
    command -v "$command_name" >/dev/null 2>&1 || {
        echo "ОШИБКА: после установки недоступна команда $command_name" >&2
        exit 1
    }
done

echo "Установка конфигурации Xray..."
mkdir -p /opt/etc/xray/configs /opt/etc/xray/dat /opt/var/log/xray
for managed_config in 01_log.json 02_inbounds.json 03_policy.json 05_routing.json; do
    cp "$BUNDLE_DIR/payload/xray/$managed_config" "/opt/etc/xray/configs/$managed_config"
done
if [ -f "$work_dir/04_outbounds.json" ]; then
    cp -p "$work_dir/04_outbounds.json" /opt/etc/xray/configs/04_outbounds.json
else
    cp "$BUNDLE_DIR/payload/xray/04_outbounds.json" /opt/etc/xray/configs/04_outbounds.json
fi
chmod 600 /opt/etc/xray/configs/*.json

for source_path in \
    /opt/share/v2ray/geoip.dat \
    /opt/share/xray/geoip.dat \
    /opt/etc/xray/geoip.dat; do
    if [ -f "$source_path" ]; then
        cp "$source_path" /opt/etc/xray/dat/geoip_v2fly.dat
        cp "$source_path" /opt/etc/xray/dat/geoip.dat
        break
    fi
done
for source_path in \
    /opt/share/v2ray/geosite.dat \
    /opt/share/xray/geosite.dat \
    /opt/etc/xray/geosite.dat; do
    if [ -f "$source_path" ]; then
        cp "$source_path" /opt/etc/xray/dat/geosite_v2fly.dat
        cp "$source_path" /opt/etc/xray/dat/geosite.dat
        break
    fi
done

cp "$BUNDLE_DIR"/payload/S24xray /opt/etc/init.d/S24xray
chmod 755 /opt/etc/init.d/S24xray

echo "Установка Orbit..."
mkdir -p /opt/orbit /opt/lib/orbit /opt/etc/orbit
rm -f /opt/etc/orbit/edition
rm -f /opt/etc/orbit/community.yaml
rm -f /opt/var/lib/orbit/access-community /opt/var/lib/orbit/community-runtime.lock
mkdir -p /opt/var/lib/orbit/routing /opt/var/lib/orbit/protection /opt/var/log/orbit /opt/etc/ndm/netfilter.d
cp "$BUNDLE_DIR"/payload/orbit-mipsel /opt/orbit/orbit.new
chmod 755 /opt/orbit/orbit.new
mv -f /opt/orbit/orbit.new /opt/orbit/orbit
cp "$BUNDLE_DIR"/uninstall.sh /opt/lib/orbit/uninstall.sh
cp "$BUNDLE_DIR"/acceptance.sh /opt/lib/orbit/acceptance.sh
[ -f /opt/etc/orbit/config.yaml ] || \
    cp "$BUNDLE_DIR"/payload/config.yaml /opt/etc/orbit/config.yaml
[ -f /opt/etc/orbit/network.conf ] || \
    cp "$BUNDLE_DIR"/payload/network.conf /opt/etc/orbit/network.conf
cp "$BUNDLE_DIR"/payload/orbit-network /opt/lib/orbit/orbit-network
cp "$BUNDLE_DIR"/payload/orbit-netfilter-hook /opt/etc/ndm/netfilter.d/orbit.sh
cp "$BUNDLE_DIR"/payload/S25orbit-network /opt/etc/init.d/S25orbit-network
cp "$BUNDLE_DIR"/payload/S99orbit /opt/etc/init.d/.S99orbit.new
chmod 755 /opt/etc/init.d/.S99orbit.new
mv -f /opt/etc/init.d/.S99orbit.new /opt/etc/init.d/S99orbit

sed -i "s/^POLICY_NAME=.*/POLICY_NAME=$POLICY_NAME/" /opt/etc/orbit/network.conf
chmod 755 /opt/orbit/orbit /opt/lib/orbit/orbit-network
chmod 755 /opt/lib/orbit/uninstall.sh /opt/lib/orbit/acceptance.sh
chmod 755 /opt/etc/ndm/netfilter.d/orbit.sh
chmod 755 /opt/etc/init.d/S25orbit-network /opt/etc/init.d/S99orbit
chmod 600 /opt/etc/orbit/config.yaml /opt/etc/orbit/network.conf
[ ! -f /opt/var/lib/orbit/subscription.json ] || chmod 600 /opt/var/lib/orbit/subscription.json
if [ "$RESET_DATA" = "no" ] && [ -d "$work_dir/routing" ]; then
    for migrated_list in "$work_dir"/routing/*.lst; do
        [ -f "$migrated_list" ] || continue
        destination="/opt/var/lib/orbit/routing/$(basename "$migrated_list")"
        [ -f "$destination" ] || cp -p "$migrated_list" "$destination"
    done
fi
chmod 700 /opt/var/lib/orbit/routing
chmod 700 /opt/var/lib/orbit/protection
chmod 600 /opt/var/lib/orbit/routing/* 2>/dev/null || true
chmod 600 /opt/var/lib/orbit/protection/* 2>/dev/null || true

echo "Проверка Xray-конфигурации..."
XRAY_LOCATION_ASSET=/opt/etc/xray/dat \
    /opt/sbin/xray run -test -confdir /opt/etc/xray/configs

echo "Запуск Xray..."
/opt/etc/init.d/S24xray start
sleep 2
/opt/etc/init.d/S24xray status

port_has_socket() {
    port="$1"
    protocol="$2"
    hex_port=$(printf '%04X' "$port")
    grep -Eiq ":${hex_port}[[:space:]]" \
        "/proc/net/$protocol" "/proc/net/${protocol}6" 2>/dev/null
}

if ! port_has_socket 1181 tcp || ! port_has_socket 1181 udp; then
    echo "ОШИБКА: Xray запущен, но вход 1181 не слушает TCP и UDP." >&2
    /opt/etc/init.d/S24xray stop 2>/dev/null || true
    exit 1
fi

echo "Запуск панели Orbit..."
/opt/etc/init.d/S99orbit start
/opt/orbit/orbit -config /opt/etc/orbit/config.yaml --wait-ready

echo "Подготовка политики и сетевого слоя Orbit..."
# Backend создаёт политику через локальный Keenetic RCI при первом запуске.
# Ожидание исключает гонку между запуском панели и сетевого слоя.
attempt=0
while [ "$attempt" -lt 10 ]; do
    /opt/etc/init.d/S25orbit-network restart >/dev/null 2>&1 && break
    attempt=$((attempt + 1))
    sleep 1
done
if ! /opt/etc/init.d/S25orbit-network status; then
    echo "ОШИБКА: сетевой слой Orbit не активирован." >&2
    echo "Запустите sh $BUNDLE_DIR/diagnose.sh и сохраните вывод." >&2
    exit 1
fi
echo ""
echo "=== Установка завершена ==="
echo "Панель: http://orbit.home"
echo "Резервный адрес: http://<IP-адрес Keenetic>:3000"
echo "Диагностика: sh $BUNDLE_DIR/diagnose.sh"
echo "Резервная копия прежних данных: $backup_dir"
if [ "$RESET_DATA" = "no" ]; then
    echo "Настройки, подписки и выбранные серверы сохранены."
else
    echo "Пользовательские данные сброшены по параметру --reset-data."
fi
echo ""
echo "После первичной настройки добавьте подписку и выберите сервер."
echo "Устройства назначаются политике на странице Orbit -> Устройства."
echo "Статус Orbit будет проверять интернет через локальный proxy Xray,"
echo "поэтому прямое соединение мимо туннеля больше не даст ложный зелёный статус."
install_completed=yes
