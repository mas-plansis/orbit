#!/bin/sh

set -u

PATH="/opt/bin:/opt/sbin:/usr/sbin:/usr/bin:/sbin:/bin"
LIFECYCLE=no
case "${1:-}" in
    "") ;;
    --lifecycle) LIFECYCLE=yes ;;
    *) echo "Использование: sh acceptance.sh [--lifecycle]" >&2; exit 2 ;;
esac
[ "$#" -le 1 ] || { echo "Использование: sh acceptance.sh [--lifecycle]" >&2; exit 2; }

failures=0
recovery_needed=no

pass() {
    echo "OK   $*"
}

fail() {
    echo "FAIL $*" >&2
    failures=$((failures + 1))
}

run_check() {
    label="$1"
    shift
    if "$@" >/dev/null 2>&1; then
        pass "$label"
    else
        fail "$label"
    fi
}

port_has_socket() {
    port="$1"
    protocol="$2"
    hex_port=$(printf '%04X' "$port")
    grep -Eiq ":${hex_port}[[:space:]]" \
        "/proc/net/$protocol" "/proc/net/${protocol}6" 2>/dev/null
}

rules_present() {
    iptables -w -t nat -S ORBIT_TCP >/dev/null 2>&1 && return 0
    iptables -w -t mangle -S ORBIT_UDP >/dev/null 2>&1 && return 0
    iptables -w -t nat -S PREROUTING 2>/dev/null | grep -q -- '-j ORBIT_TCP' && return 0
    iptables -w -t mangle -S PREROUTING 2>/dev/null | grep -q -- '-j ORBIT_UDP' && return 0
    return 1
}

restore_services() {
    [ "$recovery_needed" = "yes" ] || return 0
    /opt/etc/init.d/S24xray start >/dev/null 2>&1 || true
    attempt=0
    while [ "$attempt" -lt 10 ]; do
        /opt/etc/init.d/S25orbit-network restart >/dev/null 2>&1 && break
        attempt=$((attempt + 1))
        sleep 1
    done
    recovery_needed=no
}

trap restore_services EXIT INT TERM

echo "=== Orbit: приёмка установки ==="
run_check "Бинарник Orbit установлен" test -x /opt/orbit/orbit
run_check "Бинарник Xray установлен" test -x /opt/sbin/xray
run_check "Сценарий сети Orbit установлен" test -x /opt/lib/orbit/orbit-network
run_check "Пользовательский outbound существует" test -f /opt/etc/xray/configs/04_outbounds.json

if XRAY_LOCATION_ASSET=/opt/etc/xray/dat \
    /opt/sbin/xray run -test -confdir /opt/etc/xray/configs >/dev/null 2>&1; then
    pass "Конфигурация Xray корректна"
else
    fail "Конфигурация Xray не прошла xray run -test"
fi

run_check "Orbit запущена" /opt/etc/init.d/S99orbit status
run_check "Xray запущен" /opt/etc/init.d/S24xray status
run_check "TCP-вход Xray слушает 1181" port_has_socket 1181 tcp
run_check "UDP-вход Xray слушает 1181" port_has_socket 1181 udp
run_check "Правила прозрачной маршрутизации активны" /opt/lib/orbit/orbit-network status
run_check "Политика L4 создана и соответствует схеме" sh -c \
    "jq -e '.schema_version == 1 and (.enabled | type == \"boolean\") and (.rules | type == \"array\")' /opt/var/lib/orbit/protection/l4-policy.json"
run_check "Локальная сеть исключена из TCP-перехвата" sh -c \
    "iptables -w -t nat -S ORBIT_TCP | grep -q -- '-d 192.168.0.0/16 .* -j RETURN'"
run_check "API Orbit доступен локально" wget -qO- \
    http://127.0.0.1:3000/api/v1/auth/status

if [ "$LIFECYCLE" = "yes" ]; then
    echo ""
    echo "Проверка безопасной остановки и восстановления..."
    recovery_needed=yes
    if /opt/lib/orbit/orbit-network force-stop >/dev/null 2>&1 && \
       /opt/etc/init.d/S24xray stop >/dev/null 2>&1; then
        pass "Xray и сетевой слой остановлены"
    else
        fail "Не удалось безопасно остановить Xray и сетевой слой"
    fi
    if rules_present; then
        fail "После остановки остались правила Orbit"
    else
        pass "После остановки правила перехвата полностью удалены"
    fi
    restore_services
    run_check "Xray восстановлен после проверки" /opt/etc/init.d/S24xray status
    run_check "Маршрутизация восстановлена после проверки" /opt/lib/orbit/orbit-network status
fi

echo ""
if [ "$failures" -eq 0 ]; then
    echo "РЕЗУЛЬТАТ: автоматические проверки пройдены."
    echo "Для завершения приёмки откройте сайт с устройства политики Orbit,"
    echo "сверьте внешний IP и убедитесь, что панель Keenetic остаётся доступной."
    exit 0
fi

echo "РЕЗУЛЬТАТ: ошибок — $failures." >&2
exit 1
