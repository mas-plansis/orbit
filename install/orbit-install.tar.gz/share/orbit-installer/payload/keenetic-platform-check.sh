#!/bin/sh

# Единая проверка версии KeeneticOS для автоматического и ручного
# установщиков. Функция не изменяет роутер и может вызываться до
# запуска Entware.
orbit_require_supported_keenetic_os() {
    orbit_version_output="${1:-}"
    orbit_version_major=$(
        printf '%s\n' "$orbit_version_output" |
            sed -n \
                -e 's/.*[Rr]elease[^:]*:[^0-9]*\([0-9][0-9]*\).*/\1/p' \
                -e 's/.*[Tt]itle[^:]*:[[:space:]"]*\([0-9][0-9]*\).*/\1/p' \
                -e 's/.*KeeneticOS[^0-9]*\([0-9][0-9]*\).*/\1/p' |
            sed -n '1p'
    )

    case "$orbit_version_major" in
        ''|*[!0-9]*)
            printf '%s\n' 'ОШИБКА: не удалось определить версию KeeneticOS.' >&2
            printf 'Ответ роутера: %s\n' "${orbit_version_output:-не получен}" >&2
            return 1
            ;;
    esac

    if [ "$orbit_version_major" -lt 5 ]; then
        printf 'ОШИБКА: Orbit требует KeeneticOS 5 или новее. Определена версия %s.\n' "$orbit_version_major" >&2
        return 1
    fi
}
