#!/bin/sh

set -eu

PATH="/opt/bin:/opt/sbin:/usr/sbin:/usr/bin:/sbin:/bin"
PURGE_DATA=no
case "${1:-}" in
    "") ;;
    --purge-data) PURGE_DATA=yes ;;
    *) echo "Использование: sh uninstall.sh [--purge-data]" >&2; exit 2 ;;
esac
[ "$#" -le 1 ] || { echo "Использование: sh uninstall.sh [--purge-data]" >&2; exit 2; }

[ "$(id -u)" = "0" ] || { echo "Удаление нужно запустить от root" >&2; exit 1; }
[ -d /opt ] || { echo "/opt не смонтирован; удаление остановлено" >&2; exit 1; }

rules_present() {
    if command -v iptables >/dev/null 2>&1; then
        iptables -w -t nat -S ORBIT_TCP >/dev/null 2>&1 && return 0
        iptables -w -t mangle -S ORBIT_UDP >/dev/null 2>&1 && return 0
        iptables -w -t nat -S PREROUTING 2>/dev/null | grep -q -- '-j ORBIT_TCP' && return 0
        iptables -w -t mangle -S PREROUTING 2>/dev/null | grep -q -- '-j ORBIT_UDP' && return 0
    fi
    if command -v ip6tables >/dev/null 2>&1; then
        ip6tables -w -t nat -S ORBIT_TCP >/dev/null 2>&1 && return 0
        ip6tables -w -t mangle -S ORBIT_UDP >/dev/null 2>&1 && return 0
        ip6tables -w -t nat -S PREROUTING 2>/dev/null | grep -q -- '-j ORBIT_TCP' && return 0
        ip6tables -w -t mangle -S PREROUTING 2>/dev/null | grep -q -- '-j ORBIT_UDP' && return 0
    fi
    ip rule show 2>/dev/null | grep -Eq 'fwmark (0x)?0*66.*lookup 118' && return 0
    ip -6 rule show 2>/dev/null | grep -Eq 'fwmark (0x)?0*66.*lookup 118' && return 0
    ip route show table 118 2>/dev/null | grep -q . && return 0
    ip -6 route show table 118 2>/dev/null | grep -q . && return 0
    return 1
}

echo "Остановка Orbit..."
[ -x /opt/etc/init.d/S99orbit ] && /opt/etc/init.d/S99orbit stop 2>/dev/null || true
[ -x /opt/etc/init.d/S98orbit-update-agent ] && /opt/etc/init.d/S98orbit-update-agent stop 2>/dev/null || true

echo "Удаление правил перехвата..."
if [ -x /opt/lib/orbit/orbit-network ]; then
    /opt/lib/orbit/orbit-network force-stop
elif rules_present; then
    echo "ОШИБКА: правила Orbit активны, а модуль очистки недоступен." >&2
    echo "Файлы не удалены, чтобы не оставить трафик в неисправной цепочке." >&2
    exit 1
fi
if rules_present; then
    echo "ОШИБКА: не удалось подтвердить удаление всех правил Orbit." >&2
    echo "Файлы не удалены." >&2
    exit 1
fi

echo "Остановка Xray..."
[ -x /opt/etc/init.d/S24xray ] && /opt/etc/init.d/S24xray stop 2>/dev/null || true

# Убираем только bind-mount, содержимое которого принадлежит Orbit.
stock_index=/usr/share/htdocs_/index.html
orbit_index=/tmp/orbit-keenetic-webui/index.html
if grep -q " $stock_index " /proc/self/mountinfo 2>/dev/null && \
   [ -f "$orbit_index" ] && cmp -s "$orbit_index" "$stock_index"; then
    umount "$stock_index" || {
        echo "ОШИБКА: не удалось убрать пункт Orbit из Web UI Keenetic." >&2
        exit 1
    }
fi
rm -rf /tmp/orbit-keenetic-webui

# Локальное имя и HTTP-прокси больше не должны вести на удалённую Orbit.
if command -v ndmc >/dev/null 2>&1; then
    ndmc -c "no ip host orbit.home" >/dev/null 2>&1 || true
    ndmc -c "no ip http proxy orbit" >/dev/null 2>&1 || true
    ndmc -c "system configuration save" >/dev/null 2>&1 || true
fi

echo "Удаление исполняемых и управляемых файлов..."
rm -f /opt/etc/init.d/S99orbit
rm -f /opt/etc/init.d/S98orbit-update-agent
rm -f /opt/sbin/orbit-update-agent /opt/sbin/orbit-update-agent.protocol
rm -f /opt/etc/init.d/S25orbit-network
rm -f /opt/etc/init.d/S24xray
rm -f /opt/etc/ndm/netfilter.d/orbit.sh
rm -rf /opt/orbit
rm -rf /opt/lib/orbit
rm -f /opt/etc/xray/configs/01_log.json
rm -f /opt/etc/xray/configs/00_api.json
rm -f /opt/etc/xray/configs/02_inbounds.json
rm -f /opt/etc/xray/configs/03_policy.json
rm -f /opt/etc/xray/configs/05_routing.json
rm -f /opt/var/lib/orbit/network.disabled
rm -f /opt/var/lib/orbit/core.disabled
command -v opkg >/dev/null 2>&1 && opkg remove xray xray-core >/dev/null 2>&1 || true

if [ "$PURGE_DATA" = "yes" ]; then
    echo "Удаление пользовательских данных по параметру --purge-data..."
    rm -rf /opt/etc/orbit
    rm -rf /opt/var/lib/orbit
    rm -rf /opt/var/log/orbit
    rm -rf /opt/etc/xray
    rm -rf /opt/var/log/xray
else
    echo "Настройки и пользовательские данные сохранены на накопителе /opt."
fi

echo "Orbit удалена. Политика Orbit в Keenetic сохранена и теперь использует обычный WAN."
