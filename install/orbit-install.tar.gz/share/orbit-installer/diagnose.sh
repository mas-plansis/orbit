#!/bin/sh

PATH="/opt/bin:/opt/sbin:/usr/sbin:/usr/bin:/sbin:/bin"

echo "=== Orbit: диагностика установки ==="
echo ""

echo "[1/8] Файлы и зависимости"
for path in \
    /opt/orbit/orbit \
    /opt/sbin/xray \
    /opt/etc/xray/configs/02_inbounds.json \
    /opt/etc/xray/configs/00_api.json \
    /opt/etc/xray/configs/04_outbounds.json \
    /opt/lib/orbit/orbit-network \
    /opt/etc/ndm/netfilter.d/orbit.sh; do
    if [ -e "$path" ]; then echo "OK  $path"; else echo "FAIL $path"; fi
done
for command_name in iptables jq insmod; do
    if command -v "$command_name" >/dev/null 2>&1; then
        echo "OK  $command_name: $(command -v "$command_name")"
    else
        echo "FAIL команда $command_name не найдена"
    fi
done
for module_name in xt_comment xt_TPROXY; do
    if grep -q "^${module_name} " /proc/modules 2>/dev/null; then
        echo "OK  модуль $module_name загружен"
    else
        echo "FAIL модуль $module_name не загружен"
    fi
done

echo ""
echo "[2/8] Проверка Xray-конфига"
XRAY_LOCATION_ASSET=/opt/etc/xray/dat \
    /opt/sbin/xray run -test -confdir /opt/etc/xray/configs 2>&1 || true

echo ""
echo "[3/8] Процессы"
/opt/etc/init.d/S24xray status 2>&1 || true
/opt/etc/init.d/S99orbit status 2>&1 || true

echo ""
echo "[4/8] Локальные порты Xray"
for socket in tcp:1181 udp:1181 tcp:10808 udp:10808 tcp:10809; do
    protocol=${socket%%:*}
    port=${socket#*:}
    hex_port=$(printf '%04X' "$port")
    if grep -Eiq ":${hex_port}[[:space:]]" \
        "/proc/net/$protocol" "/proc/net/${protocol}6" 2>/dev/null; then
        echo "OK  $protocol/$port слушается"
    else
        echo "FAIL $protocol/$port не слушается"
    fi
done

echo ""
echo "[5/8] Политика и правила"
/opt/lib/orbit/orbit-network status 2>&1 || true
[ ! -f /opt/var/lib/orbit/protection/l4-policy.json ] || \
    jq '{schema_version, enabled, rules}' /opt/var/lib/orbit/protection/l4-policy.json 2>&1 || true
iptables -w -t nat -S ORBIT_TCP 2>&1 || true
iptables -w -t mangle -S ORBIT_UDP 2>&1 || true
ip6tables -w -t nat -S ORBIT_TCP 2>&1 || true
ip6tables -w -t mangle -S ORBIT_UDP 2>&1 || true

echo ""
echo "[6/8] Счётчики перехвата"
iptables -w -t nat -L ORBIT_TCP -n -v 2>&1 || true
iptables -w -t mangle -L ORBIT_UDP -n -v 2>&1 || true
ip6tables -w -t nat -L ORBIT_TCP -n -v 2>&1 || true
ip6tables -w -t mangle -L ORBIT_UDP -n -v 2>&1 || true

echo ""
echo "[7/8] API Orbit"
wget -qO- http://127.0.0.1:3000/api/v1/auth/status 2>/dev/null || \
    echo "FAIL: API Orbit не отвечает"
echo ""

echo "[8/8] Последние журналы"
tail -n 20 /opt/var/log/orbit/orbit.log 2>/dev/null || true
tail -n 20 /opt/var/log/xray/error.log 2>/dev/null || true

echo ""
echo "Во время открытия сайта на устройстве из политики Orbit проверьте счётчики:"
echo "  iptables -t nat -L ORBIT_TCP -n -v"
echo "  iptables -t mangle -L ORBIT_UDP -n -v"
