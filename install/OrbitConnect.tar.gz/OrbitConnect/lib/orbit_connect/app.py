from __future__ import annotations

import fcntl
import os
import sys
import threading
import time
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Callable

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk

try:
    from PyQt6.QtCore import Qt
    from PyQt6.QtGui import QAction, QColor, QIcon, QPainter, QPalette, QPixmap
    from PyQt6.QtWidgets import QApplication, QMenu, QStyle, QSystemTrayIcon
except ImportError:
    Qt = QAction = QColor = QIcon = QPainter = QPalette = QPixmap = QApplication = QMenu = QStyle = QSystemTrayIcon = None

try:
    gi.require_version("AyatanaAppIndicator3", "0.1")
    from gi.repository import AyatanaAppIndicator3 as AppIndicator
except (ValueError, ImportError):
    try:
        gi.require_version("AppIndicator3", "0.1")
        from gi.repository import AppIndicator3 as AppIndicator
    except (ValueError, ImportError):
        AppIndicator = None

from . import __version__
from .autostart import AutostartManager, startup_arguments
from .core import (
    APP_ID,
    ConnectUpdate,
    DiscoveryRetrySchedule,
    OrbitAPI,
    OrbitError,
    OrbitNotFound,
    Settings,
    TokenStore,
    TrafficPauseAlertTracker,
    default_gateway,
    network_fingerprint,
    normalize_pairing_key,
    route_steps,
)
from .updater import LinuxUpdater, detect_install_kind


COLORS = {
    "unknown": "#94a3b8",
    "orbit": "#22c55e",
    "direct": "#ef4444",
    "blocked": "#ef4444",
}

COUNTRIES = {
    "DE": "Германия",
    "FI": "Финляндия",
    "FR": "Франция",
    "GB": "Великобритания",
    "NL": "Нидерланды",
    "RU": "Россия",
    "SE": "Швеция",
    "US": "США",
}


def resource_path(name: str) -> Path:
    local = Path(__file__).resolve().parent / "assets" / name
    if local.exists():
        return local
    return Path("/usr/share/orbit-connect") / name


def label(text: str = "", css_class: str | None = None, *, xalign: float = 0) -> Gtk.Label:
    widget = Gtk.Label(label=text, xalign=xalign)
    widget.set_line_wrap(True)
    widget.set_selectable(False)
    if css_class:
        widget.get_style_context().add_class(css_class)
    return widget


class OrbitConnectApplication(Gtk.Application):
    def __init__(self, *, start_hidden: bool = False) -> None:
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.start_hidden = start_hidden
        self.settings = Settings()
        config = self.settings.load()
        self.base_url = str(config.get("base_url") or "http://orbit.home")
        self.store = TokenStore(self.settings)
        self.token = self.store.load()
        self.api = OrbitAPI(__version__)
        self.install_kind = detect_install_kind()
        self.updater = LinuxUpdater(self.install_kind)
        self.status: dict[str, Any] | None = None
        self.device = ""
        self.error_message = ""
        self.pairing_key = ""
        self.discovery_retry = DiscoveryRetrySchedule()
        self.last_network = network_fingerprint()
        self.last_network_check = time.monotonic()
        self.last_rebind_attempt = 0.0
        self.busy = False
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="orbit-connect")
        self.window: Gtk.ApplicationWindow | None = None
        self.content: Gtk.Box | None = None
        self.indicator = None
        self.status_icon = None
        self.tray_menu: Gtk.Menu | None = None
        self.qt_app = None
        self.qt_tray = None
        self.qt_menu = None
        self.qt_pump_source = 0
        self.poll_source = 0
        self.traffic_pause_alert_tracker = TrafficPauseAlertTracker()
        self.traffic_pause_dialog: Gtk.MessageDialog | None = None
        self.autostart = AutostartManager()
        self.dark_theme = self._prefers_dark_theme()
        try:
            self.autostart.ensure_default_enabled()
        except OSError:
            pass

    def do_startup(self) -> None:
        Gtk.Application.do_startup(self)
        self._install_css()
        self._create_indicator()

    def do_activate(self) -> None:
        self._ensure_window()
        if not self.start_hidden:
            self._present_window()
        self.start_hidden = False
        self._start_polling()
        self.refresh()

    def _ensure_window(self) -> None:
        if self.window is None:
            self.window = Gtk.ApplicationWindow(application=self)
            self.window.set_title("Orbit Connect")
            self.window.set_default_size(430, 560)
            self.window.set_resizable(False)
            window_icon = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                str(resource_path("orbit-window-icon.svg")), 64, 64, True
            )
            self.window.set_icon(window_icon)
            self.window.connect("delete-event", self._hide_window)
            self.content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
            self.content.set_border_width(18)
            self.window.add(self.content)
            self._render()

    def _present_window(self) -> None:
        self._ensure_window()
        self.window.show_all()
        self.window.present()

    def _start_polling(self) -> None:
        if not self.poll_source:
            self.poll_source = GLib.timeout_add_seconds(3, self._poll)

    def do_shutdown(self) -> None:
        if self.poll_source:
            GLib.source_remove(self.poll_source)
        if self.qt_pump_source:
            GLib.source_remove(self.qt_pump_source)
        if self.qt_tray is not None:
            self.qt_tray.hide()
        if self.traffic_pause_dialog is not None:
            self.traffic_pause_dialog.destroy()
            self.traffic_pause_dialog = None
        self.executor.shutdown(wait=False, cancel_futures=True)
        Gtk.Application.do_shutdown(self)

    def _install_css(self) -> None:
        palette = (
            {
                "canvas": "#0e151f",
                "card": "#171f2b",
                "border": "#2b394b",
                "ink": "#eef4fb",
                "muted": "#9aa9bc",
                "input": "#1d2836",
                "button": "#202c3b",
                "separator": "#2b394b",
                "error_bg": "#341d25",
                "error": "#ff818c",
                "warning_bg": "#33291a",
                "warning": "#f5b75c",
            }
            if self.dark_theme
            else {
                "canvas": "#f5f8fc",
                "card": "#ffffff",
                "border": "#dce6f2",
                "ink": "#28364d",
                "muted": "#74839c",
                "input": "#ffffff",
                "button": "#f7f9fc",
                "separator": "#e2eaf3",
                "error_bg": "#fff0f1",
                "error": "#d93d4a",
                "warning_bg": "#fff8e6",
                "warning": "#95500d",
            }
        )
        css = f"""
        window, dialog, messagedialog {{ background: {palette['canvas']}; color: {palette['ink']}; }}
        * {{ font-family: Inter, Geist, system-ui, sans-serif; font-size: 14px; }}
        .card {{ background: {palette['card']}; border: 1px solid {palette['border']}; border-radius: 22px; padding: 16px; }}
        .title {{ font-size: 22px; font-weight: 700; color: {palette['ink']}; }}
        .heading {{ font-size: 15px; font-weight: 700; color: {palette['ink']}; }}
        .value {{ font-size: 17px; font-weight: 700; color: {palette['ink']}; }}
        .muted {{ color: {palette['muted']}; }}
        .caption {{ color: {palette['muted']}; font-size: 12px; }}
        .status-dot {{ font-size: 18px; }}
        .route-row {{ padding: 7px 0; }}
        .error {{ background: {palette['error_bg']}; color: {palette['error']}; border-radius: 16px; padding: 11px; }}
        .warning {{ background: {palette['warning_bg']}; color: {palette['warning']}; border-radius: 16px; padding: 11px; }}
        entry {{ min-height: 38px; border: 1px solid {palette['border']}; border-radius: 13px; padding: 0 12px; background: {palette['input']}; color: {palette['ink']}; caret-color: {palette['ink']}; }}
        button {{ min-height: 36px; border-radius: 13px; padding: 0 15px; border: 1px solid {palette['border']}; background: {palette['button']}; color: {palette['ink']}; }}
        button.primary {{ background: #32bdb4; border-color: #32bdb4; color: #ffffff; font-weight: 700; }}
        button.danger {{ color: #df3e4d; }}
        separator {{ background: {palette['separator']}; min-height: 1px; }}
        """.encode("utf-8")
        provider = Gtk.CssProvider()
        provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

    @staticmethod
    def _prefers_dark_theme() -> bool:
        forced = os.environ.get("ORBIT_CONNECT_THEME", "").strip().lower()
        if forced in {"dark", "light"}:
            return forced == "dark"
        settings = Gtk.Settings.get_default()
        if settings is None:
            return False
        try:
            if bool(settings.get_property("gtk-application-prefer-dark-theme")):
                return True
        except TypeError:
            pass
        try:
            return "dark" in str(settings.get_property("gtk-theme-name") or "").lower()
        except TypeError:
            return False

    def _create_indicator(self) -> None:
        if QApplication is not None and QSystemTrayIcon is not None:
            self._create_qt_indicator()
            return

        menu = Gtk.Menu()
        self._append_menu_item(menu, "Открыть KeeneticOS", "network-router-symbolic", self.open_keenetic)
        self._append_menu_item(menu, "Открыть Orbit", "applications-internet-symbolic", self.open_orbit)
        menu.append(Gtk.SeparatorMenuItem())
        self._append_menu_item(menu, "Настройки", "preferences-system-symbolic", self.open_settings)
        self._append_menu_item(menu, "Перезапустить Orbit Connect", "view-refresh-symbolic", self.restart)
        self._append_menu_item(menu, "Проверить обновления", "software-update-available-symbolic", self.check_updates)
        self._append_menu_item(menu, "Разорвать связь", "edit-unlink-symbolic", self.confirm_unlink)
        menu.append(Gtk.SeparatorMenuItem())
        self._append_menu_item(menu, "Закрыть", "application-exit-symbolic", self.quit)
        menu.show_all()
        self.tray_menu = menu

        icon_theme_path = str(resource_path("orbit-connect-unknown-dark.svg").parent)
        Gtk.IconTheme.get_default().append_search_path(icon_theme_path)
        icon = str(resource_path("orbit-connect-unknown-dark.svg"))
        # AppIndicator is the supported tray implementation in current Linux
        # desktops. Gtk.StatusIcon may be constructed successfully while the
        # shell silently refuses to display it, leaving a headless process.
        if AppIndicator is not None:
            self.indicator = AppIndicator.Indicator.new(
                APP_ID, icon, AppIndicator.IndicatorCategory.APPLICATION_STATUS
            )
            self.indicator.set_icon_theme_path(icon_theme_path)
            self.indicator.set_status(AppIndicator.IndicatorStatus.ACTIVE)
            self.indicator.set_menu(menu)
            self.indicator.set_title("Orbit Connect")
            return

        try:
            self.status_icon = Gtk.StatusIcon.new_from_file(icon)
            self.status_icon.set_visible(True)
            self.status_icon.set_tooltip_text("Orbit Connect")
            self.status_icon.connect("activate", lambda *_: self.show_window())
            self.status_icon.connect(
                "popup-menu",
                lambda _icon, button, when: menu.popup(
                    None, None, None, None, button, when
                ),
            )
        except (AttributeError, RuntimeError, TypeError):
            self.status_icon = None

    def _create_qt_indicator(self) -> None:
        self.qt_app = QApplication.instance() or QApplication(["orbit-connect"])
        self.qt_app.setQuitOnLastWindowClosed(False)
        if self.dark_theme:
            palette = self.qt_app.palette()
            for role, value in (
                (QPalette.ColorRole.Window, "#171f2b"),
                (QPalette.ColorRole.WindowText, "#eef4fb"),
                (QPalette.ColorRole.Base, "#171f2b"),
                (QPalette.ColorRole.AlternateBase, "#202c3b"),
                (QPalette.ColorRole.Text, "#eef4fb"),
                (QPalette.ColorRole.Button, "#202c3b"),
                (QPalette.ColorRole.ButtonText, "#eef4fb"),
                (QPalette.ColorRole.Highlight, "#246e6c"),
                (QPalette.ColorRole.HighlightedText, "#ffffff"),
            ):
                palette.setColor(role, QColor(value))
            self.qt_app.setPalette(palette)
        self.qt_menu = QMenu()
        self._append_qt_menu_item(
            "Открыть KeeneticOS", "network-server", self.open_keenetic,
            QStyle.StandardPixmap.SP_DriveNetIcon, resource_path("menu-keenetic.svg"),
        )
        self._append_qt_menu_item(
            "Открыть Orbit", "orbit-connect", self.open_orbit,
            QStyle.StandardPixmap.SP_ComputerIcon, resource_path("orbit-menu-icon.svg"),
        )
        self.qt_menu.addSeparator()
        self._append_qt_menu_item(
            "Настройки", "preferences-system", self.open_settings,
            QStyle.StandardPixmap.SP_FileDialogDetailedView,
        )
        self._append_qt_menu_item(
            "Перезапустить Orbit Connect", "view-refresh", self.restart,
            QStyle.StandardPixmap.SP_BrowserReload, resource_path("menu-restart.svg"),
        )
        self._append_qt_menu_item(
            "Проверить обновления", "system-software-update", self.check_updates,
            QStyle.StandardPixmap.SP_ArrowDown, resource_path("menu-update.svg"),
        )
        self._append_qt_menu_item(
            "Разорвать связь", "edit-unlink", self.confirm_unlink,
            QStyle.StandardPixmap.SP_DialogDiscardButton, resource_path("menu-unlink.svg"),
        )
        self.qt_menu.addSeparator()
        self._append_qt_menu_item(
            "Закрыть", "application-exit", self.quit,
            QStyle.StandardPixmap.SP_DialogCloseButton, resource_path("menu-close.svg"),
        )

        self.qt_tray = QSystemTrayIcon()
        self.qt_tray.setContextMenu(self.qt_menu)
        self.qt_tray.setToolTip("Orbit Connect")
        self.qt_tray.activated.connect(self._qt_indicator_activated)
        self.qt_tray.show()
        self.qt_pump_source = GLib.timeout_add(16, self._pump_qt)
        self._update_indicator()

    def _append_qt_menu_item(
        self,
        title: str,
        theme_icon: str,
        callback: Callable[[], None],
        fallback: Any,
        asset: Path | None = None,
    ) -> None:
        icon = self._themed_qt_icon(asset) if asset else QIcon.fromTheme(theme_icon)
        if icon.isNull():
            icon = self.qt_app.style().standardIcon(fallback)
        action = QAction(icon, title, self.qt_menu)
        action.triggered.connect(
            lambda _checked=False, handler=callback: GLib.idle_add(self._run_tray_action, handler)
        )
        self.qt_menu.addAction(action)

    def _themed_qt_icon(self, asset: Path | None) -> QIcon:
        if asset is None:
            return QIcon()
        source = QPixmap(str(asset))
        if source.isNull():
            return QIcon()
        tinted = QPixmap(source.size())
        tinted.fill(Qt.GlobalColor.transparent)
        painter = QPainter(tinted)
        painter.drawPixmap(0, 0, source)
        painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceIn)
        painter.fillRect(
            tinted.rect(),
            self.qt_menu.palette().color(QPalette.ColorRole.Text),
        )
        painter.end()
        return QIcon(tinted)

    @staticmethod
    def _run_tray_action(callback: Callable[[], None]) -> bool:
        callback()
        return False

    def _qt_indicator_activated(self, reason: Any) -> None:
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            GLib.idle_add(self._run_tray_action, self.show_window)

    def _pump_qt(self) -> bool:
        if self.qt_app is not None:
            self.qt_app.processEvents()
        return True

    def _tray_icon_path(self, state: str) -> Path:
        palette = self.qt_app.palette()
        dark_background = palette.color(QPalette.ColorRole.Window).lightness() < 128
        tone = "light" if dark_background else "dark"
        return resource_path(f"orbit-connect-{state}-{tone}.svg")

    def _append_menu_item(
        self, menu: Gtk.Menu, title: str, icon_name: str, callback: Callable[[], None]
    ) -> None:
        item = Gtk.ImageMenuItem(label=title)
        item.set_image(Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.MENU))
        item.set_always_show_image(True)
        item.connect("activate", lambda *_: callback())
        menu.append(item)

    def _hide_window(self, *_args: Any) -> bool:
        if self.window:
            self.window.hide()
        return True

    def show_window(self) -> None:
        self._present_window()
        self._start_polling()
        self.refresh()

    def open_settings(self) -> None:
        self._ensure_window()
        dialog = Gtk.Dialog(
            title="Настройки",
            transient_for=self.window,
            modal=True,
        )
        dialog.add_button("Готово", Gtk.ResponseType.CLOSE)
        dialog.set_default_size(390, -1)

        content = dialog.get_content_area()
        content.set_spacing(12)
        content.set_border_width(18)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        text.pack_start(label("Запускать при входе в систему", "heading"), False, False, 0)
        text.pack_start(
            label("При автозапуске открывается только значок в области уведомлений.", "muted"),
            False,
            False,
            0,
        )
        switch = Gtk.Switch()
        switch.set_valign(Gtk.Align.CENTER)
        switch.set_active(self.autostart.is_enabled())
        error = label("", "error")
        error.set_no_show_all(True)

        def change_autostart(widget: Gtk.Switch, _state: Any) -> None:
            try:
                self.autostart.set_enabled(widget.get_active())
                error.hide()
            except OSError:
                error.set_text("Не удалось изменить автозапуск")
                error.show()

        switch.connect("notify::active", change_autostart)
        row.pack_start(text, True, True, 0)
        row.pack_end(switch, False, False, 0)
        content.pack_start(row, False, False, 0)
        content.pack_start(error, False, False, 0)
        dialog.show_all()
        error.hide()
        dialog.run()
        dialog.destroy()

    def _poll(self) -> bool:
        now = time.monotonic()
        network_check_interval = 3 if self.discovery_retry.can_attempt(now) else 15
        if now - self.last_network_check >= network_check_interval:
            self.last_network_check = now
            fingerprint = network_fingerprint()
            if fingerprint != self.last_network:
                self.last_network = fingerprint
                self.discovery_retry.reset()
                self.error_message = ""
        self.refresh()
        return True

    def refresh(self) -> None:
        if not self.token:
            self.status = None
            self._update_indicator()
            return
        if self.busy or not self.discovery_retry.can_attempt():
            return
        self._submit(self._load_status, self._apply_status)

    def _load_status(self) -> tuple[str, dict[str, Any]]:
        base_url = self.api.discover(self.base_url)
        latest = self.api.status(base_url, self.token or "")
        if latest.get("mac_changed") and time.monotonic() - self.last_rebind_attempt >= 300:
            self.last_rebind_attempt = time.monotonic()
            latest = self.api.rebind(base_url, self.token or "")
        return base_url, latest

    def _apply_status(self, result: tuple[str, dict[str, Any]]) -> None:
        self.base_url, self.status = result
        self.device = str(self.status.get("device") or self.device)
        self.settings.save({"base_url": self.base_url})
        self.discovery_retry.reset()
        self.error_message = ""
        self._render()
        self._update_indicator()

    def pair(self, entry: Gtk.Entry) -> None:
        self.pairing_key = entry.get_text()
        key = normalize_pairing_key(self.pairing_key)
        if not key:
            self.error_message = "Введите ключ связи"
            self._render()
            return

        def work() -> tuple[str, str, str, dict[str, Any] | None]:
            base_url = self.api.discover(self.base_url)
            result = self.api.pair(base_url, key)
            latest = None
            try:
                latest = self.api.status(base_url, result.token)
            except OrbitError:
                pass
            return base_url, result.token, result.device, latest

        def apply(result: tuple[str, str, str, dict[str, Any] | None]) -> None:
            self.base_url, self.token, self.device, self.status = result
            self.store.save(self.token)
            self.settings.save({"base_url": self.base_url})
            self.pairing_key = ""
            self.discovery_retry.reset()
            self.error_message = ""
            self._render()
            self._update_indicator()

        self._submit(work, apply)

    def confirm_unlink(self) -> None:
        if not self.token:
            return
        dialog = Gtk.MessageDialog(
            transient_for=self.window,
            modal=True,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.CANCEL,
            text="Разорвать связь приложения с устройством?",
        )
        dialog.format_secondary_text("Приложение потеряет доступ к Orbit. Сетевые настройки устройства не изменятся.")
        dialog.add_button("Разорвать связь", Gtk.ResponseType.OK)
        if dialog.run() == Gtk.ResponseType.OK:
            previous_token = self.token
            self.store.delete()
            self.token = None
            self.status = None
            self.device = ""
            self.error_message = ""
            self.discovery_retry.reset()
            self._render()
            self._update_indicator()

            def revoke() -> None:
                try:
                    base_url = self.api.discover(self.base_url)
                    self.api.revoke(base_url, previous_token or "")
                except OrbitError:
                    pass

            self.executor.submit(revoke)
        dialog.destroy()

    def retry_static_exit(self) -> None:
        if not self.token:
            return

        def work() -> dict[str, Any]:
            base_url = self.api.discover(self.base_url)
            return self.api.retry_static_exit(base_url, self.token or "")

        self._submit(work, self._apply_static_status)

    def disable_static_exit(self) -> None:
        if not self.token:
            return

        def work() -> dict[str, Any]:
            base_url = self.api.discover(self.base_url)
            return self.api.disable_static_exit(base_url, self.token or "")

        self._submit(work, self._apply_static_status)

    def _apply_static_status(self, status: dict[str, Any]) -> None:
        self.status = status
        self.error_message = ""
        self._render()
        self._update_indicator()

    def _submit(self, work: Callable[[], Any], apply: Callable[[Any], None]) -> None:
        if self.busy:
            return
        self.busy = True

        def completed(future: Any) -> None:
            try:
                result = future.result()
            except OrbitNotFound as error:
                GLib.idle_add(self._handle_not_found, str(error))
            except Exception as error:
                GLib.idle_add(self._handle_error, str(error))
            else:
                GLib.idle_add(self._handle_success, apply, result)

        future = self.executor.submit(work)
        future.add_done_callback(completed)

    def _handle_success(self, apply: Callable[[Any], None], result: Any) -> bool:
        self.busy = False
        apply(result)
        return False

    def _handle_not_found(self, message: str) -> bool:
        self.busy = False
        delay = self.discovery_retry.record_failure()
        if delay is None:
            self.error_message = message
        else:
            self.error_message = (
                "Orbit не найдена в локальной сети. "
                f"Повторим поиск через {self._discovery_delay_label(delay)}."
            )
        self._render()
        self._update_indicator()
        return False

    def _handle_error(self, message: str) -> bool:
        self.busy = False
        self.discovery_retry.reset()
        self.error_message = message or "Не удалось выполнить запрос"
        self._render()
        self._update_indicator()
        return False

    @staticmethod
    def _discovery_delay_label(delay: int) -> str:
        hours = delay // 3600
        if hours:
            return "1 час" if hours == 1 else f"{hours} ч"
        return f"{delay // 60} мин"

    def _connection_state(self) -> str:
        if not self.token or not self.status:
            return "unknown"
        if self.status.get("traffic_blocked") or self.status.get("static_exit_blocked"):
            return "blocked"
        if self.status.get("using_orbit") and not self.status.get("mac_changed"):
            return "orbit"
        return "direct"

    def _update_indicator(self) -> None:
        state = self._connection_state()
        title = {
            "unknown": "Orbit Connect: состояние неизвестно",
            "orbit": "Orbit Connect: подключено через Orbit",
            "direct": "Orbit Connect: прямой выход",
            "blocked": "Orbit Connect: трафик приостановлен",
        }[state]
        if self.qt_tray is not None:
            self.qt_tray.setIcon(QIcon(str(self._tray_icon_path(state))))
            self.qt_tray.setToolTip(title)
        if self.indicator is not None:
            self.indicator.set_icon_full(str(resource_path(f"orbit-connect-{state}-dark.svg")), title)
        if self.status_icon is not None:
            self.status_icon.set_from_file(str(resource_path(f"orbit-connect-{state}-dark.svg")))
            self.status_icon.set_tooltip_text(title)
        self._sync_traffic_pause_alert(state == "blocked")

    def _sync_traffic_pause_alert(self, is_blocked: bool) -> None:
        action = self.traffic_pause_alert_tracker.update(is_blocked=is_blocked)
        if action == "present":
            self._present_traffic_pause_alert()
        elif action == "dismiss":
            self._dismiss_traffic_pause_alert()

    def _present_traffic_pause_alert(self) -> None:
        parent = self.window if self.window is not None and self.window.get_visible() else None
        dialog = Gtk.MessageDialog(
            transient_for=parent,
            modal=True,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.NONE,
            text="Трафик приостановлен",
        )
        dialog.add_button("Закрыть", Gtk.ResponseType.CLOSE)
        dialog.format_secondary_text(
            "Статический выход недоступен. Orbit остановил трафик, чтобы исключить "
            "прямой выход. Когда выход заработает, доступ вернётся сам. Окно можно закрыть."
        )
        dialog.set_title("Orbit Connect")
        dialog.set_position(Gtk.WindowPosition.CENTER_ALWAYS)
        dialog.connect("response", lambda current, _response: current.destroy())
        dialog.connect("destroy", self._traffic_pause_alert_destroyed)
        self.traffic_pause_dialog = dialog
        dialog.show_all()
        dialog.present()

    def _dismiss_traffic_pause_alert(self) -> None:
        if self.traffic_pause_dialog is None:
            return
        dialog = self.traffic_pause_dialog
        self.traffic_pause_dialog = None
        dialog.destroy()

    def _traffic_pause_alert_destroyed(self, dialog: Gtk.MessageDialog) -> None:
        if self.traffic_pause_dialog is not dialog:
            return
        self.traffic_pause_dialog = None
        self.traffic_pause_alert_tracker.did_dismiss()

    def _clear_content(self) -> None:
        if not self.content:
            return
        for child in self.content.get_children():
            self.content.remove(child)

    def _render(self) -> None:
        if not self.content:
            return
        self._clear_content()
        self.content.pack_start(self._header_card(), False, False, 0)
        if self.token:
            self.content.pack_start(self._status_content(), False, False, 0)
        else:
            self.content.pack_start(self._pairing_card(), False, False, 0)
        if self.error_message:
            error = label(self.error_message, "error")
            self.content.pack_start(error, False, False, 0)
        self.content.show_all()
        if self.window:
            self.window.resize(430, 1)

    def _header_card(self) -> Gtk.Box:
        card = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        card.get_style_context().add_class("card")
        source_logo = GdkPixbuf.Pixbuf.new_from_file(
            str(resource_path("orbit-window-icon.svg"))
        )
        logo = source_logo.scale_simple(54, 54, GdkPixbuf.InterpType.BILINEAR)
        image = Gtk.Image.new_from_pixbuf(logo)
        image.set_size_request(54, 54)
        mark = Gtk.Overlay()
        mark.set_size_request(58, 58)
        mark.add(image)
        dot = label("●", "status-dot")
        dot.set_halign(Gtk.Align.END)
        dot.set_valign(Gtk.Align.END)
        status_color = Gdk.RGBA()
        status_color.parse(COLORS[self._connection_state()])
        dot.override_color(Gtk.StateFlags.NORMAL, status_color)
        mark.add_overlay(dot)
        card.pack_start(mark, False, False, 0)
        titles = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        title_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
        title_row.pack_start(label("Orbit Connect", "title"), False, False, 0)
        title_row.pack_start(label(f"v{__version__}", "muted"), False, False, 0)
        titles.pack_start(title_row, False, False, 0)
        subtitle = self.device if self.token and self.device else ("Устройство связано" if self.token else "Устройство не связано")
        titles.pack_start(label(subtitle, "muted"), False, False, 0)
        card.pack_start(titles, True, True, 0)
        return card

    def _pairing_card(self) -> Gtk.Box:
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        card.get_style_context().add_class("card")
        card.pack_start(label("Связать с Orbit", "heading"), False, False, 0)
        card.pack_start(
            label("В Orbit откройте «Устройства», выберите меню устройства и нажмите «Связь с приложением».", "muted"),
            False,
            False,
            0,
        )
        entry = Gtk.Entry()
        entry.set_placeholder_text("Ключ связи")
        entry.set_visibility(False)
        entry.set_input_purpose(Gtk.InputPurpose.PASSWORD)
        entry.set_text(self.pairing_key)
        entry.connect("changed", lambda field: setattr(self, "pairing_key", field.get_text()))
        entry.connect("activate", lambda *_: self.pair(entry))
        card.pack_start(entry, False, False, 0)
        button = Gtk.Button(label="Подключить")
        button.get_style_context().add_class("primary")
        button.connect("clicked", lambda *_: self.pair(entry))
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        row.pack_start(button, False, False, 0)
        card.pack_start(row, False, False, 0)
        return card

    def _status_content(self) -> Gtk.Box:
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        summary = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        summary.pack_start(self._metric_card("Конечный адрес", str((self.status or {}).get("final_ip") or "Не определён")), True, True, 0)
        code = str((self.status or {}).get("country_code") or "").upper()
        summary.pack_start(self._metric_card("Регион", COUNTRIES.get(code, code or "Не определён")), True, True, 0)
        content.pack_start(summary, False, False, 0)

        route = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        route.get_style_context().add_class("card")
        route.pack_start(label("Маршрут", "heading"), False, False, 3)
        steps = route_steps(self.status)
        if not steps:
            route.pack_start(label("Маршрут пока не определён", "muted"), False, False, 4)
        for step in steps:
            route.pack_start(self._route_row(step), False, False, 0)
        content.pack_start(route, False, False, 0)

        if (self.status or {}).get("static_exit_blocked") or (self.status or {}).get("traffic_blocked"):
            warning = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            warning.get_style_context().add_class("warning")
            warning.pack_start(label(str((self.status or {}).get("static_exit_error") or "Статический выход недоступен"), "heading"), False, False, 0)
            warning.pack_start(label("Трафик устройства приостановлен до восстановления требуемого выхода.", "muted"), False, False, 0)
            actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            retry = Gtk.Button(label="Повторить")
            retry.connect("clicked", lambda *_: self.retry_static_exit())
            disable = Gtk.Button(label="Отключить контроль")
            disable.connect("clicked", lambda *_: self.disable_static_exit())
            actions.pack_start(retry, False, False, 0)
            actions.pack_start(disable, False, False, 0)
            warning.pack_start(actions, False, False, 0)
            content.pack_start(warning, False, False, 0)

        return content

    def _metric_card(self, title: str, value: str) -> Gtk.Box:
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        card.get_style_context().add_class("card")
        card.pack_start(label(title, "muted"), False, False, 0)
        card.pack_start(label(value, "value"), False, False, 0)
        return card

    def _route_row(self, step: dict[str, str]) -> Gtk.Box:
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=9)
        row.get_style_context().add_class("route-row")
        role = step.get("role") or "route"
        icon_name = {
            "device": "computer-symbolic",
            "primary": "network-server-symbolic",
            "static": "network-server-symbolic",
            "internet": "network-workgroup-symbolic",
        }.get(role, "network-transmit-receive-symbolic")
        row.pack_start(Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.BUTTON), False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        title = step.get("label") or step.get("server") or "Маршрут"
        details = " · ".join(value for value in [step.get("protocol"), step.get("server"), step.get("country_code"), step.get("ip")] if value)
        text.pack_start(label(title, "heading"), False, False, 0)
        if details:
            text.pack_start(label(details, "caption"), False, False, 0)
        row.pack_start(text, True, True, 0)
        return row

    def open_orbit(self) -> None:
        self._open_discovered("")

    def open_keenetic(self) -> None:
        gateway = default_gateway()
        if not gateway:
            self.error_message = "Не удалось определить локальный шлюз"
            self._render()
            return
        webbrowser.open(f"http://{gateway}")

    def _open_discovered(self, path: str) -> None:
        def work() -> str:
            return self.api.discover(self.base_url)

        def apply(base_url: str) -> None:
            self.base_url = base_url
            webbrowser.open(base_url.rstrip("/") + path)

        self._submit(work, apply)

    def restart(self) -> None:
        os.execv(sys.executable, [sys.executable, *sys.argv])

    def check_updates(self) -> None:
        def apply(update: ConnectUpdate | None) -> None:
            dialog = Gtk.MessageDialog(
                transient_for=self.window,
                modal=True,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text=(f"Доступна версия {update.version}" if update else "Установлена актуальная версия"),
            )
            if update:
                action = "Скачать вручную" if update.package_kind == "portable" else "Обновить"
                dialog.add_button(action, Gtk.ResponseType.APPLY)
            if dialog.run() == Gtk.ResponseType.APPLY and update:
                if update.package_kind == "portable":
                    webbrowser.open(update.download_url)
                else:
                    self._install_update(update)
            dialog.destroy()

        self._submit(lambda: self.api.latest_update(self.install_kind), apply)

    def _install_update(self, update: ConnectUpdate) -> None:
        progress = Gtk.MessageDialog(
            transient_for=self.window,
            modal=True,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.NONE,
            text=f"Устанавливаем Orbit Connect v{update.version}",
        )
        progress.format_secondary_text("Загружаем и проверяем пакет обновления…")
        spinner = Gtk.Spinner()
        spinner.start()
        progress.get_message_area().pack_start(spinner, False, False, 6)
        progress.show_all()

        def work() -> None:
            package = self.updater.download_and_verify(update)
            GLib.idle_add(
                progress.format_secondary_text,
                "Пакет проверен. Подтвердите установку в системном окне.",
            )
            self.updater.install(package)

        def completed(future: Any) -> None:
            try:
                future.result()
            except Exception as error:
                GLib.idle_add(self._finish_update_with_error, progress, update, str(error))
            else:
                GLib.idle_add(self._finish_update_successfully, progress)

        self.executor.submit(work).add_done_callback(completed)

    def _finish_update_successfully(self, progress: Gtk.MessageDialog) -> bool:
        progress.destroy()
        self.restart()
        return False

    def _finish_update_with_error(
        self,
        progress: Gtk.MessageDialog,
        update: ConnectUpdate,
        message: str,
    ) -> bool:
        progress.destroy()
        dialog = Gtk.MessageDialog(
            transient_for=self.window,
            modal=True,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.CLOSE,
            text="Не удалось установить обновление",
        )
        dialog.format_secondary_text(message or "Текущая версия Orbit Connect не изменена.")
        dialog.add_button("Скачать вручную", Gtk.ResponseType.APPLY)
        if dialog.run() == Gtk.ResponseType.APPLY:
            webbrowser.open(update.download_url)
        dialog.destroy()
        return False


def acquire_lock() -> Any:
    runtime = Path(os.environ.get("XDG_RUNTIME_DIR", "/tmp"))
    lock_path = runtime / f"orbit-connect-{os.getuid()}.lock"
    handle = lock_path.open("w")
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        return None
    return handle


def main() -> int:
    lock = acquire_lock()
    if lock is None:
        return 0
    arguments, start_hidden = startup_arguments(sys.argv)
    application = OrbitConnectApplication(start_hidden=start_hidden)
    application._instance_lock = lock
    return application.run(arguments)


if __name__ == "__main__":
    raise SystemExit(main())
