from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path


AUTOSTART_FILE_NAME = "io.orbit.Connect.desktop"


def _desktop_boolean(content: str, key: str) -> bool | None:
    prefix = f"{key}="
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line.startswith(prefix):
            continue
        value = line[len(prefix) :].strip().lower()
        if value in {"true", "1", "yes"}:
            return True
        if value in {"false", "0", "no"}:
            return False
    return None


def _quote_desktop_argument(value: str) -> str:
    escaped = value.replace("\\", "\\\\").replace('"', '\\"').replace("`", "\\`")
    return f'"{escaped}"'


def application_command() -> str:
    installed = shutil.which("orbit-connect")
    if installed:
        return installed
    return str(Path(sys.argv[0]).expanduser().resolve())


def startup_arguments(arguments: list[str]) -> tuple[list[str], bool]:
    return (
        [argument for argument in arguments if argument != "--background"],
        "--background" in arguments,
    )


class AutostartManager:
    def __init__(
        self,
        *,
        config_home: Path | None = None,
        system_directories: tuple[Path, ...] | None = None,
        command: str | None = None,
    ) -> None:
        root = config_home or Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
        self.user_file = root / "autostart" / AUTOSTART_FILE_NAME
        self.system_directories = system_directories or self._system_directories()
        self.command = command or application_command()

    @staticmethod
    def _system_directories() -> tuple[Path, ...]:
        raw = os.environ.get("XDG_CONFIG_DIRS", "/etc/xdg")
        return tuple(Path(item) for item in raw.split(":") if item)

    def is_enabled(self) -> bool:
        if self.user_file.exists():
            return self._file_is_enabled(self.user_file)
        return any(
            self._file_is_enabled(directory / "autostart" / AUTOSTART_FILE_NAME)
            for directory in self.system_directories
            if (directory / "autostart" / AUTOSTART_FILE_NAME).exists()
        )

    def ensure_default_enabled(self) -> None:
        if self.user_file.exists() or any(
            (directory / "autostart" / AUTOSTART_FILE_NAME).exists()
            for directory in self.system_directories
        ):
            return
        self.set_enabled(True)

    def set_enabled(self, enabled: bool) -> None:
        self.user_file.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        temporary = self.user_file.with_suffix(".tmp")
        temporary.write_text(self._desktop_entry(enabled), encoding="utf-8")
        temporary.chmod(0o600)
        temporary.replace(self.user_file)

    @staticmethod
    def _file_is_enabled(path: Path) -> bool:
        try:
            content = path.read_text(encoding="utf-8")
        except OSError:
            return False
        if _desktop_boolean(content, "Hidden") is True:
            return False
        return _desktop_boolean(content, "X-GNOME-Autostart-enabled") is not False

    def _desktop_entry(self, enabled: bool) -> str:
        state = "true" if enabled else "false"
        hidden = "false" if enabled else "true"
        return (
            "[Desktop Entry]\n"
            "Type=Application\n"
            "Name=Orbit Connect\n"
            "Comment=Состояние подключения устройства через Orbit\n"
            f"Exec={_quote_desktop_argument(self.command)} --background\n"
            "Icon=orbit-connect\n"
            "Terminal=false\n"
            "StartupNotify=false\n"
            f"X-GNOME-Autostart-enabled={state}\n"
            f"Hidden={hidden}\n"
        )
