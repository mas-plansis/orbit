from __future__ import annotations

import hashlib
import hmac
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.error
import urllib.request
from pathlib import Path

from .core import ConnectUpdate, OrbitError


MAX_PACKAGE_BYTES = 128 * 1024 * 1024
MAX_CHECKSUM_BYTES = 1024 * 1024


class UpdateError(OrbitError):
    pass


def detect_install_kind(root: Path = Path("/")) -> str:
    if (root / "var/lib/dpkg/info/orbit-connect.list").exists():
        return "deb"
    pacman_root = root / "var/lib/pacman/local"
    if pacman_root.exists() and any(pacman_root.glob("orbit-connect-*")):
        return "arch"
    executable = Path(sys.argv[0]).expanduser().resolve()
    if executable == root / "usr/bin/orbit-connect":
        if shutil.which("pacman"):
            return "arch"
        return "deb"
    return "portable"


def parse_checksum(content: str, filename: str) -> str:
    for raw_line in content.splitlines():
        parts = raw_line.strip().split()
        if len(parts) < 2:
            continue
        digest = parts[0].lower()
        candidate = parts[-1].lstrip("*")
        if candidate == filename and len(digest) == 64:
            try:
                int(digest, 16)
            except ValueError:
                continue
            return digest
    raise UpdateError("В релизе отсутствует контрольная сумма пакета")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _download(url: str, destination: Path, limit: int) -> None:
    if not url.startswith("https://github.com/mas-plansis/orbit/releases/download/"):
        raise UpdateError("Источник обновления не прошёл проверку")
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "OrbitConnect-Updater"},
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response, destination.open("wb") as target:
            expected = response.headers.get("Content-Length")
            if expected and int(expected) > limit:
                raise UpdateError("Пакет обновления слишком большой")
            written = 0
            while chunk := response.read(1024 * 1024):
                written += len(chunk)
                if written > limit:
                    raise UpdateError("Пакет обновления слишком большой")
                target.write(chunk)
    except UpdateError:
        raise
    except (OSError, ValueError, urllib.error.URLError) as error:
        raise UpdateError("Не удалось загрузить обновление") from error


def _validate_deb(path: Path, version: str) -> None:
    with path.open("rb") as source:
        header = source.read(8)
    if header != b"!<arch>\n":
        raise UpdateError("Загруженный DEB-пакет повреждён")
    tool = shutil.which("dpkg-deb")
    if not tool:
        return
    result = subprocess.run(
        [tool, "-f", str(path), "Package", "Version"],
        capture_output=True,
        text=True,
        timeout=15,
        check=False,
    )
    values = result.stdout.splitlines()
    if result.returncode != 0 or values[:2] != ["orbit-connect", version]:
        raise UpdateError("DEB-пакет не соответствует Orbit Connect")


def _validate_arch(path: Path, version: str) -> None:
    with path.open("rb") as source:
        header = source.read(4)
    if header != bytes.fromhex("28b52ffd"):
        raise UpdateError("Загруженный пакет Arch повреждён")
    tool = shutil.which("tar")
    if not tool:
        raise UpdateError("Для проверки пакета требуется tar")
    result = subprocess.run(
        [tool, "--zstd", "-xOf", str(path), ".PKGINFO"],
        capture_output=True,
        text=True,
        timeout=20,
        check=False,
    )
    if result.returncode != 0:
        raise UpdateError("Не удалось проверить пакет Arch")
    metadata = dict(
        line.split(" = ", 1)
        for line in result.stdout.splitlines()
        if " = " in line
    )
    if metadata.get("pkgname") != "orbit-connect" or metadata.get("pkgver") != f"{version}-1":
        raise UpdateError("Пакет Arch не соответствует Orbit Connect")


def _validate_portable(path: Path) -> None:
    try:
        with tarfile.open(path, "r:gz") as archive:
            members = archive.getmembers()
            names = {member.name for member in members}
            if "OrbitConnect/orbit-connect" not in names:
                raise UpdateError("Переносимый архив не соответствует Orbit Connect")
            for member in members:
                member_path = Path(member.name)
                if member_path.is_absolute() or ".." in member_path.parts or member.issym() or member.islnk():
                    raise UpdateError("Переносимый архив содержит небезопасные пути")
    except (OSError, tarfile.TarError) as error:
        raise UpdateError("Переносимый архив повреждён") from error


class LinuxUpdater:
    def __init__(self, install_kind: str | None = None) -> None:
        self.install_kind = install_kind or detect_install_kind()

    def download_and_verify(self, update: ConnectUpdate) -> Path:
        if update.package_kind != self.install_kind:
            raise UpdateError("Пакет обновления не соответствует способу установки")
        directory = Path(tempfile.mkdtemp(prefix="orbit-connect-update-"))
        package = directory / update.asset_name
        checksum_file = directory / "SHA256SUMS"
        try:
            _download(update.download_url, package, MAX_PACKAGE_BYTES)
            _download(update.checksum_url, checksum_file, MAX_CHECKSUM_BYTES)
            expected = parse_checksum(
                checksum_file.read_text(encoding="utf-8"),
                update.asset_name,
            )
            if not hmac.compare_digest(sha256_file(package), expected):
                raise UpdateError("Контрольная сумма обновления не совпала")
            if self.install_kind == "deb":
                _validate_deb(package, update.version)
            elif self.install_kind == "arch":
                _validate_arch(package, update.version)
            else:
                _validate_portable(package)
            return package
        except Exception:
            shutil.rmtree(directory, ignore_errors=True)
            raise

    def install(self, package: Path) -> None:
        try:
            if self.install_kind == "portable":
                raise UpdateError(
                    "Автоматическая установка переносимой версии пока недоступна. Скачайте архив вручную."
                )
            command = self._install_command(package)
            result = subprocess.run(command, check=False)
            if result.returncode != 0:
                raise UpdateError("Установка обновления отменена или завершилась с ошибкой")
        except OSError as error:
            raise UpdateError("Не удалось запустить системную установку") from error
        finally:
            shutil.rmtree(package.parent, ignore_errors=True)

    def _install_command(self, package: Path) -> list[str]:
        if self.install_kind == "deb":
            installer = shutil.which("apt-get")
            arguments = [installer, "install", "-y", str(package)] if installer else []
        else:
            installer = shutil.which("pacman")
            arguments = [installer, "-U", "--noconfirm", str(package)] if installer else []
        if not arguments or not installer:
            raise UpdateError("Системный менеджер пакетов не найден")
        if os.geteuid() == 0:
            return arguments
        pkexec = shutil.which("pkexec")
        if not pkexec:
            raise UpdateError("Для установки требуется системный запрос прав администратора")
        return [pkexec, *arguments]
