from __future__ import annotations

import ipaddress
import json
import os
import re
import shutil
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any

APP_ID = "io.orbit.Connect"
SECRET_SERVICE = "io.orbit.status"
SECRET_ACCOUNT = "device-link"
GITHUB_RELEASES_URL = "https://api.github.com/repos/mas-plansis/orbit/releases?per_page=20"
DISCOVERY_RETRY_DELAYS = (
    15 * 60,
    30 * 60,
    60 * 60,
    2 * 60 * 60,
    4 * 60 * 60,
    8 * 60 * 60,
    16 * 60 * 60,
    24 * 60 * 60,
)


class OrbitError(RuntimeError):
    pass


class OrbitNotFound(OrbitError):
    pass


class DiscoveryRetrySchedule:
    attempts_per_round = 3

    def __init__(self) -> None:
        self.attempts_in_round = 0
        self.delay_index = 0
        self.retry_after: float | None = None

    def can_attempt(self, now: float | None = None) -> bool:
        current = time.monotonic() if now is None else now
        return self.retry_after is None or current >= self.retry_after

    def record_failure(self, now: float | None = None) -> int | None:
        current = time.monotonic() if now is None else now
        self.attempts_in_round += 1
        if self.attempts_in_round < self.attempts_per_round:
            return None

        self.attempts_in_round = 0
        delay = DISCOVERY_RETRY_DELAYS[self.delay_index]
        self.retry_after = current + delay
        self.delay_index = min(self.delay_index + 1, len(DISCOVERY_RETRY_DELAYS) - 1)
        return delay

    def reset(self) -> None:
        self.attempts_in_round = 0
        self.delay_index = 0
        self.retry_after = None


@dataclass(frozen=True)
class PairResult:
    token: str
    device: str


@dataclass(frozen=True)
class ConnectUpdate:
    version: str
    download_url: str
    checksum_url: str
    asset_name: str
    package_kind: str


def normalize_pairing_key(value: str) -> str:
    return "".join(character for character in value.upper() if character.isascii() and character.isalnum())


def version_key(value: str) -> tuple[int, ...]:
    return tuple(int(part) for part in re.findall(r"\d+", value))


def _run(command: list[str], timeout: float = 2.0) -> str:
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            check=False,
            text=True,
            timeout=timeout,
        )
    except (OSError, subprocess.TimeoutExpired):
        return ""
    return result.stdout.strip() if result.returncode == 0 else ""


def default_gateway() -> str | None:
    output = _run(["ip", "-4", "route", "show", "default"])
    for line in output.splitlines():
        parts = line.split()
        if "via" in parts:
            index = parts.index("via")
            if index + 1 < len(parts):
                return parts[index + 1]
    try:
        with open("/proc/net/route", encoding="utf-8") as routes:
            next(routes, None)
            for line in routes:
                parts = line.split()
                if len(parts) < 3 or parts[1] != "00000000":
                    continue
                raw = bytes.fromhex(parts[2])
                return ".".join(str(part) for part in reversed(raw))
    except (OSError, ValueError):
        return None
    return None


def default_interface() -> str | None:
    output = _run(["ip", "-4", "route", "show", "default"])
    for line in output.splitlines():
        parts = line.split()
        if "dev" in parts:
            index = parts.index("dev")
            if index + 1 < len(parts):
                return parts[index + 1]
    try:
        with open("/proc/net/route", encoding="utf-8") as routes:
            next(routes, None)
            for line in routes:
                parts = line.split()
                if len(parts) >= 2 and parts[1] == "00000000":
                    return parts[0]
    except OSError:
        return None
    return None


def network_fingerprint() -> str:
    active = _run(["nmcli", "-t", "-f", "NAME,TYPE,DEVICE", "connection", "show", "--active"])
    return f"{active}|{default_gateway() or ''}"


def discovery_candidates(preferred_url: str | None) -> list[str]:
    candidates: list[str] = []

    def add(value: str | None) -> None:
        if not value:
            return
        normalized = value.strip().rstrip("/")
        if normalized and normalized not in candidates:
            candidates.append(normalized)

    gateway = default_gateway()
    try:
        address = ipaddress.ip_address(gateway or "")
    except ValueError:
        return candidates
    if (
        not isinstance(address, ipaddress.IPv4Address)
        or address.is_unspecified
        or address.is_multicast
        or address.is_loopback
    ):
        return candidates

    if preferred_url:
        try:
            parsed = urllib.parse.urlsplit(preferred_url.strip())
            preferred_is_gateway = (
                parsed.scheme == "http"
                and parsed.hostname == gateway
                and parsed.username is None
                and parsed.password is None
                and parsed.path in ("", "/")
                and not parsed.query
                and not parsed.fragment
            )
        except ValueError:
            preferred_is_gateway = False
        if preferred_is_gateway:
            add(preferred_url)
    add(f"http://{gateway}:3000")
    return candidates


class Settings:
    def __init__(self) -> None:
        config_root = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
        self.directory = config_root / "orbit-connect"
        self.path = self.directory / "settings.json"

    def load(self) -> dict[str, Any]:
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
            return value if isinstance(value, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {}

    def save(self, value: dict[str, Any]) -> None:
        self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.chmod(0o600)
        temporary.replace(self.path)


class TokenStore:
    """Uses Secret Service when available and a private file only as fallback."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.fallback_path = settings.directory / "credential"

    def load(self) -> str | None:
        if shutil.which("secret-tool"):
            value = _run(
                ["secret-tool", "lookup", "service", SECRET_SERVICE, "account", SECRET_ACCOUNT],
                timeout=4,
            )
            if value:
                return value
        try:
            return self.fallback_path.read_text(encoding="utf-8").strip() or None
        except OSError:
            return None

    def save(self, token: str) -> None:
        if shutil.which("secret-tool"):
            try:
                result = subprocess.run(
                    [
                        "secret-tool",
                        "store",
                        "--label=Orbit Connect",
                        "service",
                        SECRET_SERVICE,
                        "account",
                        SECRET_ACCOUNT,
                    ],
                    input=token,
                    capture_output=True,
                    check=False,
                    text=True,
                    timeout=10,
                )
                if result.returncode == 0:
                    self._delete_fallback()
                    return
            except (OSError, subprocess.TimeoutExpired):
                pass
        self.settings.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.fallback_path.write_text(token, encoding="utf-8")
        self.fallback_path.chmod(0o600)

    def delete(self) -> None:
        if shutil.which("secret-tool"):
            try:
                subprocess.run(
                    ["secret-tool", "clear", "service", SECRET_SERVICE, "account", SECRET_ACCOUNT],
                    capture_output=True,
                    check=False,
                    timeout=4,
                )
            except (OSError, subprocess.TimeoutExpired):
                pass
        self._delete_fallback()

    def _delete_fallback(self) -> None:
        try:
            self.fallback_path.unlink()
        except FileNotFoundError:
            pass


class OrbitAPI:
    def __init__(self, version: str, timeout: float = 12.0) -> None:
        self.version = version
        self.timeout = timeout

    def discover(self, preferred_url: str | None) -> str:
        for candidate in discovery_candidates(preferred_url):
            try:
                health = self._request(candidate, "/api/v1/health", timeout=2.0)
                if isinstance(health, dict) and str(health.get("orbit_version") or ""):
                    return candidate
            except OrbitError:
                continue
        raise OrbitNotFound("Orbit не найдена в локальной сети")

    def pair(self, base_url: str, key: str) -> PairResult:
        payload = self._request(
            base_url,
            "/api/v1/client/pair",
            method="POST",
            body={"key": normalize_pairing_key(key)},
        )
        return PairResult(token=str(payload["token"]), device=str(payload.get("device", "")))

    def status(self, base_url: str, token: str) -> dict[str, Any]:
        return self._request(base_url, "/api/v1/client/status", token=token)

    def rebind(self, base_url: str, token: str) -> dict[str, Any]:
        return self._request(base_url, "/api/v1/client/rebind", method="POST", token=token)

    def revoke(self, base_url: str, token: str) -> None:
        self._request(base_url, "/api/v1/client/link", method="DELETE", token=token)

    def retry_static_exit(self, base_url: str, token: str) -> dict[str, Any]:
        return self._request(base_url, "/api/v1/client/static-exit/retry", method="POST", token=token)

    def disable_static_exit(self, base_url: str, token: str) -> dict[str, Any]:
        return self._request(base_url, "/api/v1/client/static-exit", method="DELETE", token=token)

    def latest_update(self, package_kind: str = "deb") -> ConnectUpdate | None:
        request = urllib.request.Request(
            GITHUB_RELEASES_URL,
            headers={
                "Accept": "application/vnd.github+json",
                "User-Agent": f"OrbitConnect/{self.version}",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                releases = json.load(response)
        except (OSError, ValueError, urllib.error.URLError) as error:
            raise OrbitError("Не удалось проверить обновления") from error
        suffixes = {
            "deb": ".deb",
            "arch": ".pkg.tar.zst",
            "portable": ".tar.gz",
        }
        suffix = suffixes.get(package_kind)
        if suffix is None:
            raise OrbitError("Не удалось определить формат установленного Orbit Connect")
        updates: list[ConnectUpdate] = []
        pattern = re.compile(
            rf"^OrbitConnect_Linux_v(\d+\.\d+\.\d+){re.escape(suffix)}$"
        )
        for release in releases if isinstance(releases, list) else []:
            assets = release.get("assets", [])
            checksum_url = next(
                (
                    str(asset.get("browser_download_url", ""))
                    for asset in assets
                    if asset.get("name") == "SHA256SUMS"
                ),
                "",
            )
            if not checksum_url:
                continue
            for asset in assets:
                match = pattern.match(str(asset.get("name", "")))
                if match:
                    updates.append(
                        ConnectUpdate(
                            version=match.group(1),
                            download_url=str(asset.get("browser_download_url", "")),
                            checksum_url=checksum_url,
                            asset_name=str(asset.get("name", "")),
                            package_kind=package_kind,
                        )
                    )
        if not updates:
            return None
        newest = max(updates, key=lambda item: version_key(item.version))
        return newest if version_key(newest.version) > version_key(self.version) else None

    def _request(
        self,
        base_url: str,
        path: str,
        *,
        method: str = "GET",
        token: str | None = None,
        body: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        headers = {"Accept": "application/json", "User-Agent": f"OrbitConnect/{self.version}"}
        interface = default_interface()
        if interface:
            headers["X-Orbit-Adapter-ID"] = f"linux:{interface}"
            headers["X-Orbit-Adapter-Name"] = interface
        if token:
            headers["Authorization"] = f"Bearer {token}"
        data = None
        if body is not None:
            headers["Content-Type"] = "application/json"
            data = json.dumps(body).encode("utf-8")
        request = urllib.request.Request(
            base_url.rstrip("/") + path,
            method=method,
            headers=headers,
            data=data,
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout or self.timeout) as response:
                raw = response.read()
        except urllib.error.HTTPError as error:
            try:
                payload = json.loads(error.read().decode("utf-8"))
                message = payload.get("error")
            except (ValueError, UnicodeDecodeError):
                message = None
            raise OrbitError(message or "Orbit отклонил запрос") from error
        except (OSError, urllib.error.URLError) as error:
            raise OrbitError("Orbit недоступна") from error
        if not raw:
            return {}
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as error:
            raise OrbitError("Orbit вернула неожиданный ответ") from error
        if not isinstance(payload, dict):
            raise OrbitError("Orbit вернула неожиданный ответ")
        return payload


def route_steps(status: dict[str, Any] | None) -> list[dict[str, str]]:
    if not status:
        return []
    steps = status.get("route_steps")
    if isinstance(steps, list):
        result = []
        for step in steps:
            if not isinstance(step, dict):
                continue
            result.append({
                "role": str(step.get("role") or ""),
                "label": str(step.get("label") or ""),
                "server": str(step.get("server") or ""),
                "protocol": str(step.get("protocol") or ""),
                "ip": str(step.get("ip") or ""),
                "country_code": str(step.get("country_code") or ""),
            })
        return result
    chain = status.get("chain")
    if not isinstance(chain, list):
        return []
    return [
        {"role": "route", "label": str(label), "server": "", "protocol": "", "ip": "", "country_code": ""}
        for label in chain
    ]

