Orbit Connect для Linux

Для запуска нужны Python 3, GTK 3 и AppIndicator.

Debian и Ubuntu:
  sudo apt install python3 python3-gi gir1.2-gtk-3.0 gir1.2-ayatanaappindicator3-0.1 libsecret-tools iproute2

Arch Linux:
  sudo pacman -S --needed python python-gobject gtk3 libayatana-appindicator libsecret iproute2

Запуск:
  ./orbit-connect

Для обычной установки используйте пакет .deb или .pkg.tar.zst из релиза Orbit.
